
import React, { useState, useEffect, useRef } from 'react';
import {
  Palette,
  Layout,
  Image as ImageIcon,
  Type,
  Mail,
  Phone,
  MapPin,
  Linkedin,
  ExternalLink,
  Download,
  Menu,
  X,
  Maximize2,
  PenTool
} from 'lucide-react';

// Small helper: Image with graceful fallback
function ImageWithFallback({ src, alt, fallbackBg = 'bg-gray-100', children }) {
  const [error, setError] = useState(false);

  return (
    <div className={`w-full h-full relative ${fallbackBg} overflow-hidden`}>
      {!error ? (
        <img
          src={src}
          alt={alt}
          className="w-full h-full object-cover"
          onError={() => setError(true)}
        />
      ) : (
        <div className="w-full h-full flex items-center justify-center p-6 text-center">
          {children}
        </div>
      )}
    </div>
  );
}

// --- Components ---

const Navigation = ({ activeSection, scrollToSection, mobileMenuOpen, setMobileMenuOpen }) => {
  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'about', label: 'About' },
    { id: 'portfolio', label: 'Portfolio' },
    { id: 'skills', label: 'Skills' },
    { id: 'contact', label: 'Contact' },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 bg-white/90 backdrop-blur-md shadow-sm z-50 transition-all duration-300">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div
            role="button"
            tabIndex={0}
            onClick={() => scrollToSection('home')}
            onKeyDown={(e) => e.key === 'Enter' && scrollToSection('home')}
            className="flex-shrink-0 flex items-center gap-2 cursor-pointer"
            aria-label="Go to home"
          >
            <div className="w-8 h-8 bg-purple-600 rounded-lg flex items-center justify-center text-white font-bold text-xl">
              B
            </div>
            <span className="font-bold text-gray-900 text-lg tracking-tight">Bhuvana Giri</span>
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center space-x-8">
            <div className="flex items-center gap-8">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className={`${
                    activeSection === item.id
                      ? 'text-purple-600 font-semibold'
                      : 'text-gray-600 hover:text-purple-600'
                  } transition-colors text-sm uppercase tracking-wide focus:outline-none`}
                  aria-current={activeSection === item.id ? 'page' : undefined}
                >
                  {item.label}
                </button>
              ))}
            </div>

            <a
              href="/resume.pdf"
              download
              className="ml-2 inline-flex items-center gap-2 bg-gray-900 text-white px-4 py-1.5 rounded-full text-sm font-medium hover:bg-gray-800 transition-colors"
              aria-label="Download resume"
            >
              <Download size={14} /> Resume
            </a>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="text-gray-600 hover:text-gray-900 focus:outline-none"
              aria-label={mobileMenuOpen ? 'Close menu' : 'Open menu'}
            >
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-t border-gray-100">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  scrollToSection(item.id);
                  setMobileMenuOpen(false);
                }}
                className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-purple-600 hover:bg-gray-50 w-full text-left"
              >
                {item.label}
              </button>
            ))}

            <a href="/resume.pdf" download className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-purple-600 hover:bg-gray-50">
              Download Resume
            </a>
          </div>
        </div>
      )}
    </nav>
  );
};

const Hero = () => (
  <section id="home" className="min-h-screen flex items-center justify-center pt-16 bg-gradient-to-br from-purple-50 via-white to-blue-50">
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col-reverse md:flex-row items-center gap-12">
      <div className="w-full md:w-1/2 space-y-6 text-center md:text-left">
        <div className="inline-block px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-sm font-medium mb-2 animate-fade-in-up">
          Graphic Designer Based in Visakhapatnam
        </div>
        <h1 className="text-4xl md:text-6xl font-extrabold text-gray-900 leading-tight">
          Visual Storytelling through{' '}
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-blue-600">Creative Design</span>
        </h1>
        <p className="text-lg text-gray-600 max-w-lg mx-auto md:mx-0">
          I transform ideas into clean, modern visuals. Specializing in branding, social media content, and high-impact promotional designs.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start pt-4">
          <button
            onClick={() => document.getElementById('portfolio')?.scrollIntoView({ behavior: 'smooth', block: 'start' })}
            className="px-8 py-3 bg-gray-900 text-white rounded-lg font-semibold hover:bg-gray-800 transition-all transform hover:-translate-y-1 shadow-lg hover:shadow-xl"
          >
            View My Work
          </button>
          <button
            onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth', block: 'start' })}
            className="px-8 py-3 bg-white text-gray-900 border border-gray-200 rounded-lg font-semibold hover:border-purple-300 hover:bg-purple-50 transition-all"
          >
            Contact Me
          </button>
        </div>

        <div className="flex items-center justify-center md:justify-start gap-6 pt-8 text-gray-500">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-green-500 rounded-full" aria-hidden />
            <span className="text-sm">Available for Freelance</span>
          </div>
          <div className="h-4 w-px bg-gray-300" />
          <div className="text-sm">20+ Projects Completed</div>
        </div>
      </div>

      <div className="w-full md:w-1/2 flex justify-center relative">
        <div className="relative w-72 h-72 md:w-96 md:h-96">
          <div className="absolute inset-0 bg-gradient-to-tr from-purple-200 to-blue-200 rounded-full blur-3xl opacity-50 animate-pulse" />
          <div className="relative w-full h-full bg-white rounded-2xl shadow-2xl overflow-hidden border-8 border-white transform rotate-3 hover:rotate-0 transition-all duration-500">
            <ImageWithFallback src="/profile.jpg" alt="Rajapanthula Bhuvana Giri" fallbackBg="bg-gray-100">
              <div className="flex flex-col items-center justify-center text-gray-400">
                <Palette size={64} className="mb-4 text-purple-300" />
                <span className="text-sm font-medium">Rajapanthula Bhuvana Giri</span>
                <span className="text-xs">Graphic Designer</span>
              </div>
            </ImageWithFallback>
          </div>

          {/* Floating Cards */}
          <div className="absolute -bottom-6 -left-6 bg-white p-4 rounded-xl shadow-lg flex items-center gap-3 animate-bounce" style={{ animationDuration: '3s' }}>
            <div className="p-2 bg-blue-100 rounded-lg text-blue-600">
              <PenTool size={20} />
            </div>
            <div>
              <p className="text-xs text-gray-500">Expertise</p>
              <p className="text-sm font-bold text-gray-800">Branding</p>
            </div>
          </div>

          <div className="absolute -top-6 -right-6 bg-white p-4 rounded-xl shadow-lg flex items-center gap-3 animate-bounce" style={{ animationDuration: '4s' }}>
            <div className="p-2 bg-purple-100 rounded-lg text-purple-600">
              <Layout size={20} />
            </div>
            <div>
              <p className="text-xs text-gray-500">Tool</p>
              <p className="text-sm font-bold text-gray-800">Canva Pro</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

// rest of code omitted for brevity in this message; full App.jsx included in the zip
