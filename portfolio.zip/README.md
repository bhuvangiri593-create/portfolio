# Portfolio

This is a Vite + React + Tailwind portfolio project generated for Bhuvana Giri.

Run:

```
npm install
npm run dev
```
